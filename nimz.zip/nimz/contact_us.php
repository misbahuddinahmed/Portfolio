<?php 

if(isset($_POST["submit"])) {
	$name = $_POST["name"];
	$email = $_POST["email"];
	$phone = $_POST["phone"];
	$message = $_POST["message"];
	
	// Form validation
	if(!empty($name) && !empty($email)){

		// reCAPTCHA validation
		if(isset($_POST['g-recaptcha-response']) && !empty($_POST['g-recaptcha-response'])) {

    $secret = '6Lf7A8QUAAAAAGf6mwaatSsaMl1p2GU0odzehaf9';
    $verifyResponse = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret=' . $secret . '&response=' . $_POST['g-recaptcha-response']);
    $responseData = json_decode($verifyResponse);
    if ($responseData->success) {



 $msg='
	<table width="572" border="0" align="center" cellpadding="2" cellspacing="2">
	
	<td width="564" bgcolor="#525252">
	
	<table width="565" border="0" cellpadding="2" cellspacing="0" bgcolor="#EFEFEF">
             
	<tr bgcolor="#DEDEDE">
	<td height="30" colspan="2" bgcolor="#D40000"><font size="4" face="Verdana, Arial, Helvetica, sans-serif" color="#efefef"><b>AMSY SOFT INC | Contact Us</b></font></td>
	</tr>
   	<tr bgcolor="#525252">
   	<td height="1" ></td>
   	<td height="1" align="left" ></td>
    </tr>
    <tr>
    <td ><font color="#0668A9" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>Your Name</strong></font></td>
    <td bgcolor="#FFFFFF" height="25" align="left"><font size="2" color="#CB330A" face="Verdana, Arial, Helvetica, sans-serif">
    <label>'.$name.'</label></font></td>
    </tr>
	 <tr bgcolor="#525252">
    <td height="1"></td>
	<td height="1" align="left"></td>
    </tr>	   
	
		   
	
	<tr>
    <td height="25"><font color="#0668A9" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>Your Email</strong></font></td>
    <td bgcolor="#FFFFFF" height="25" align="left"><font size="2" color="#CB330A" face="Verdana, Arial, Helvetica, sans-serif">'.$email.'</font></td>
    </tr>

	<tr bgcolor="#525252">
    <td height="1"></td>
	<td height="1" align="left"></td>
    </tr>
	
	
	<tr>
    <td height="25"><font color="#0668A9" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>Phone</strong></font></td>
    <td bgcolor="#FFFFFF" height="25" align="left"><font size="2" color="#CB330A" face="Verdana, Arial, Helvetica, sans-serif">'.$phone.'</font></td>
    </tr>
	
    <tr bgcolor="#525252">
    <td height="1"></td>
	<td height="1" align="left"></td>
    </tr>
	
	
	<tr>
    <td height="25"><font color="#0668A9" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>Message</strong></font></td>
    <td bgcolor="#FFFFFF" height="25" align="left"><font size="2" color="#CB330A" face="Verdana, Arial, Helvetica, sans-serif">'.$message.'</font></td>
    </tr>
	
	<tr bgcolor="#525252">
    <td height="1"></td>
	<td height="1" align="left"></td>
    </tr>
	
	
		
	</table>';



$to = "wpdeveloperldg@gmail.com";

//$to = "persevere@versityle.net, mailto:info@versityle.net, ";
$fromName = "AMSY SOFT INC"; 
$formEmail = 'info@amsysoftinc.com';
$subject = 'AMSY SOFT INC | Contact Us';  
	$headers = "MIME-Version: 1.0" . "\r\n"; 
	$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n"; 
	$headers .= "From: $email" . "\r\n";
	$headers .= 'Reply-To: ' .$email . "\r\n";
    $headers .= 'X-Mailer: PHP/' . phpversion();

mail($to, $subject, $msg, $headers);
echo "<script>alert('Your message successfully send')</script>";

  //header("location:thankyou.php");
//   $response = array(
// 	"status" => "alert-success",
// 	"message" => "Your mail have been sent."
// );
} else {
$response = array(
	"status" => "alert-danger",
	"message" => "Robot verification failed, please try again."
);
}       
} else{ 
$response = array(
"status" => "alert-danger",
"message" => "Plese check on the reCAPTCHA box."
);
} 
}  else{ 
$response = array(
"status" => "alert-danger",
"message" => "All the fields are required."
);
}
} 
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NIMZ</title>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link rel="icon" type="image/x-icon" href="./images/32x32.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    

</head>

<body>
    <!-- **************************header************************ -->
    <header id="header">
        <div class="container">
            <div class="top_bar">
                <div class="col_full" data-aos="fade-left" data-aos-duration="1500">
                    <p>Toll Free Number</p>
                    <p><a href="tel:123-456-7890">123-456-7890</a></p>
                </div>
            </div>
            <div class="nav_bar">
                <div class="menu_left" data-aos="fade-right" data-aos-duration="1500">
                    <ul>
                        <li><a href="index.html">home</a></li>
                        <li><a href="about_us.html">about us</a></li>
                        <li><a href="services.html">services</a></li>
                    </ul>
                </div>
                <div class="logo" data-aos="zoom-in" data-aos-duration="1500">
                    <a href="#">
                        <img src="images/logo.png" alt="">
                    </a>
                </div>
                <div class="menu_right" data-aos="fade-left" data-aos-duration="1500">
                    <ul>
                        <li><a href="short_courses.html">short courses</a></li>
                        <li><a href="">contact us</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </header>

<body>
    <section id="sub_header">
        <div class="container">
            <div class="row">
            </div>
        </div>
    </section>

    <section id="contact_us">
        <div class="container">
            <div class="row">
                <div class="coll_ful">
                    <h1 data-aos="fade-down" data-aos-duration="1500"><span>contact</span> Us </h1>
                </div>
            </div>
            <div class="row2">
                <div class="contact_form">
                    <form action="">
                        <input type="text" name="name" id="name" placeholder="Full Name">
                        <input type="email" name="email" id="email" placeholder="Your Email">
                        <input type="number" name="number" id="number" placeholder="Your Number">
                        <textarea name="message" id="message" cols="30" rows="10" placeholder="Message">

                        </textarea>
                        <div class="g-recaptcha"  data-sitekey="6Lf7A8QUAAAAAE0yc7nSeWJkBEjDjnVt2aOJz_7V"></div>
    <?php if(!empty($response)) { ?>
					<div class="form-group col-12 text-center response">
						<div class="alert text-center  <?php echo $response['status']; ?>" style="color:red; font-wight:bold;">
							<?php echo $response['message']; ?>
						</div>
					</div>
						<?php } ?>
                        <a href="#">submit</a>
                    </form>
                    </div>
            </div>
        </div>
    </section>

    <footer id="footer">
        <div class="container">
            <div id="news_letter">
                <div class="container_fluid">
                    <div class="row" data-aos="fade-down" data-aos-duration="1500">
                        <div class="left">
                            <h2>newsletter</h2>
                            <p>
                                Stay up to update with our
                                latest news and products.
                            </p>
                        </div>
                        <div class="right">
                            <form action="">
                                <input type="text" name="full_name" id="name" placeholder="Full Name">
                                <input type="email" name="full_name" id="name" placeholder="Email ">
                                <a href="#">Subscribe</a>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="left" data-aos="fade-right" data-aos-duration="1500">
                    <p>© 2023 New Immigrant Zone All rights reserved.</p>
                </div>
                <div class="logo">
                    <img src="images/logo_footer.png" alt="">
                </div>
                <div class="right" data-aos="fade-left" data-aos-duration="1500">
                    <a href="#"><img src="./images/facebook.png" alt=""></a>
                    <a href="#"><img src="./images/youtube.png" alt=""></a>
                    <a href="#"><img src="./images/linkdin.png" alt=""></a>
                </div>
            </div>
        </div>
    </footer>

    <!-- top to button -->

    <a id="button" class="show"></a>
    <!-- top to button -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
        jQuery(window).scroll(function () {
            var height = jQuery(window).scrollTop();
            if (height > 100) {
                jQuery('#button').fadeIn();
            } else {
                jQuery('#button').fadeOut();
            }
        });

        jQuery("#button").click(function (event) {
            event.preventDefault();
            jQuery("html, body").animate({ scrollTop: 0 }, "slow");
            return false;
        });
    </script>
    <script>
        AOS.init();
      </script>

</body>

</html>
